<?php include("header.php");?>
<?php 
if(isset($_SESSION['logintrue']))
{
		$userid=$_SESSION['logintrue'];
		include("connect.php");
		$result=mysqli_query($con,"select *from register where id=$userid");
		$row=mysqli_fetch_assoc($result);
	?>
	<section class="jobs">
			<div class="container">
				<div class="row">
					<h4>Welcome to <?php echo ucwords($row['username']);?></h4>
					<div class="col-md-3">
						<div class="vertical-menu">
							<?php 
							if($row['profile_pic']!="")
							{
								?>
									<img src="profiles/<?php echo $row['profile_pic']?>" class="my-circle" height="60" width="60">
								<?php
							}
							else
							{
								?>
									<img src="img/avatar.png" class="my-circle" height="60" width="60">
								<?php
							}
							?>
						  <a href="home.php">My Profile</a>
						  <a href="edit.php" class="active">Edit My Profile</a>
						  <a href="upload_avatar.php">Upload Avatar</a>
						  <a href="change_pwd.php">Change Password</a>
						  <a href="logout.php">Logout</a>
						</div>
					</div>
					<div class="col-md-9">
						<h6>Edit Profile</h6>
						
						<?php 
						if(isset($_COOKIE['success']))
						{
							echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
						}
						
						if(isset($_POST['update']))
						{
							$name=$_POST['uname'];
							$mobile=$_POST['mobile'];
							$city=$_POST['city'];
							$state=$_POST['state'];
							$address=$_POST['address'];
							
							mysqli_query($con,"update register set username='$name',
							mobile='$mobile',
							city='$city',
							state='$state',
							address='$address' where id=$userid");
							
							if(mysqli_affected_rows($con)==1)
							{
								setcookie("success","Profile Updates Successfully",time()+2);
								header("location:edit.php");
							}
							else
							{
								echo "<p class='alert alert-danger'>Sorry! UNable to Update</p>";
							}
						}
						?>
						
						<form method="POST" action="">
							<div class="form-group">
								<label>UserName</label>
								<input class="form-control" type="text" name="uname" id="uname" value="<?php echo $row['username']?>">
							</div>
							
							<div class="form-group">
								<label>Mobile</label>
								<input class="form-control" type="text" name="mobile" id="mobile" value="<?php echo $row['mobile']?>">
							</div>
							
							<div class="form-group">
								<label>Address</label>
								<textarea class="form-control" type="text" name="address" id="address"><?php echo $row['address']?></textarea>
							</div>
							
							<div class="form-group">
								<label>City</label>
								<input class="form-control" type="text" name="city" id="city" value="<?php echo $row['city']?>">
							</div>
							
							<div class="form-group">
								<label>State</label>
								<select id="state" name="state" class="form-control">
			<option value="">--Select State--</option>
			<option <?php if($row['state']=="Andhrapradesh") echo "selected"?> value="Andhrapradesh">Andhrapradesh</option>
			<option <?php if($row['state']=="Telangana") echo "selected"?> value="Telangana">Telangana</option>
		</select>
							</div>
							
							<div class="form-group">
								<input class="btn btn-primary" type="submit" name="update" value="Update">
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</section>
	<?php
}
else
{
	header("Location:login.php");
}
?>
<?php include("footer.php");?>