<?php include("header.php"); ?>
		<section class="inner-banner" style="backend:#242c36 url(https://via.placeholder.com/1920x600)no-repeat;">
			<div class="container">
				<div class="caption">
					<h2>Contact Us</h2>
					<p>Get your Popular jobs <span>202 New job</span></p>
				</div>
			</div>
		</section>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<?php 
		if(isset($_POST['save']))
		{
			$name=$_POST['name'];
			$email=$_POST['email'];
			$mob=$_POST['mobile'];
			$msg=$_POST['msg'];
			
			
			
			mysqli_query($con,"insert into contact values(null,'$name','$email','$mob','$msg')");
			
			if(mysqli_affected_rows($con)==1)
			{
				$to="admin@admin.com";
				$subject="Contact Form-".$name;
				$message="HI Admin,<br><br>A Person contacted for the site information.please find the details below<br>
				Name:".$name."<br>Email:".$email."<br>Mobile:".$mob."<br>Message:".$msg."<br><br>Thanks<br>Team";
				//echo $message;
				$headers="Content-Type:text/html";
				if(mail($to,$subject,$message,$headers))
				{
					echo "<p class='alert alert-success'>Thanks, We will get back you soon</p>";
				}
				else{
					echo "<p class='alert alert-success'>Sorry! Unable to process</p>";
				}
			}
			else
			{
				echo "<p>Sorry! Unbale to Submit, try again</p>";
			}
			
			
		}
		?>
		
		
		<form method="POST" action="" onsubmit="return validateForm()">
			<table class="table">
			<tr>
				<td>Name</td>
				<td><input type="text" name="name" id="name" class="form-control"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input class="form-control" type="text" name="email" id="email"></td>
			</tr>
			<tr>
				<td>Mobile</td>
				<td><input class="form-control" type="text" name="mobile" id="mobile"></td>
			</tr>
			<tr>
				<td>Message</td>
				<td><textarea class="form-control" name="msg"></textarea></td>
			</tr>
			<tr>
				<td></td>
				<td><input class="btn btn-primary" type="submit" name="save" value="Send"></td>
			</tr>
		</table>
		</form>
					
					</div>
					<div class="col-md-6">
						<h4>Address</h4>
					</div>
				</div>
			</div>
		</section>
		<Script>
		function validateForm()
		{
			var n=document.getElementById("name").value;
			
			if(n=="")
			{
				alert("Enter Name");
				return false;
			}
			
			
		}
			
		</script>
	<?php include("footer.php"); ?>