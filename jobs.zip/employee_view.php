<?php include("connect.php");?>
<html>
	<head>
		<title>CRUD Operation | View Employees</title>
	</head>
	<body>
		<h1>View Employees</h1>
		<p><a href="employee_add.php">Add Employee</a></p>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<P>".$_COOKIE['success']."</p>";
		}
		?>
		
		<?php 
		$result=mysqli_query($con,"select *from employee");
		if(mysqli_num_rows($result)>0)
		{
			?>
				<table border=1>
			<tr>
				<th>Id</th>
				<th>Emp Name</th>
				<th>Email</th>
				<th>MObile</th>
				<th>Salary</th>
				<th>Designation</th>
				<th>City</th>
				<th>Joining Date</th>
				<th>Action</th>
			</tr>
			<?php 
			while($row=mysqli_fetch_assoc($result))
			{
				?>
					<tr>
				<td><?php echo $row['eid'];?></td>
				<td><?php echo $row['name'];?></td>
				<td><?php echo $row['email'];?></td>
				<td><?php echo $row['mobile'];?></td>
				<td><?php echo $row['salary'];?></td>
				<td><?php echo $row['designation'];?></td>
				<td><?php echo $row['city'];?></td>
				<td><?php echo $row['date'];?></td>
				<td><a href="employee_edit.php?empid=<?php echo $row['eid'];?>">Edit</a> | <a href="javascript:void(0)" onclick="deleteRecord(<?php echo $row['eid'];?>)">Delete</a></td>
				
			</tr>
				<?php
			}
			?>
		</table>
			<?php
		}
		else
		{
			echo "<p>No Records Found</p>";
		}
		?>
		<script>
			function deleteRecord(id)
			{
				var c=confirm("Do you want to Delete?");
				if(c==true)
				{
					window.location="employee_delete.php?did="+id;
				}
			}
		</script>
	</body>
</html>



