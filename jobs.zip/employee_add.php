<?php 
include("connect.php");
?>
<html>
	<head>
		<title>CRUD Operation | Add Employee</title>
	</head>
	<body>
		<h1>Add Employee</h1>
		<p><a href="employee_view.php">View Employees</a></p>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo $_COOKIE['success'];
		}
		
		
		if(isset($_POST['submit']))
		{
			$name=$_POST['ename'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			$desg=$_POST['desg'];
			$salary=$_POST['salary'];
			$city=$_POST['city'];
			
			mysqli_query($con,"insert into employee(name,email,mobile,salary,city,designation) values('$name','$email','$mobile','$salary','$city','$desg')");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","<p>Employee Added successfully</p>",time()+2);
				header("Location:employee_add.php");
			}
			else
			{
				echo "<p>Unable to add. Try Again</p>";
			}
			
		}
		?>
		
		<form method="post" action="" onsubmit="return empValidation()">
			<table>
				<tr>
					<td>Employee Name</td>
					<td><input type="text" name="ename" id="ename"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><input type="text" name="desg" id="desg"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Add Employee"></td>
				</tr>
			</table>
		</form>
		<script src="js/validation.js"></script>
	</body>
</html>