<?php include("header.php"); ?>
		<section class="inner-banner" style="backend:#242c36 url(https://via.placeholder.com/1920x600)no-repeat;">
			<div class="container">
				<div class="caption">
					<h2>Contact Us</h2>
					<p>Get your Popular jobs <span>202 New job</span></p>
				</div>
			</div>
		</section>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						
					
					</div>
					<div class="col-md-6">
						<h4>Address</h4>
					</div>
				</div>
			</div>
		</section>
		
	<?php include("footer.php"); ?>