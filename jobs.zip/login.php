<?php include("header.php");?>
		
		<!-- login section start -->
		<section class="login-wrapper">
			<div class="container">
				<div class="col-md-6 col-sm-8 col-md-offset-3 col-sm-offset-2">
				<?php 
		if(isset($_POST['login']))
		{
			
			$email=addslashes($_POST['email']);
			$pwd=md5($_POST['pwd']);
			
			$result=mysqli_query($con,"select *from register where email='$email'");
			if(mysqli_num_rows($result)==1)
			{
				$row=mysqli_fetch_assoc($result);
				if($row['password']==$pwd)
				{
					if($row['status']=="Active")
					{
						$_SESSION['logintrue']=$row['id'];
						$_SESSION['loginname']=$row['username'];
						header("Location:home.php");
					}
					else
					{
						echo "<p class='alert alert-warning'>Please Activate your account</p>";
					}
				}
				else
				{
					echo "<p class='alert alert-danger'>Invalid password entered for email</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger'>Email doesn't exists</p>";
			}
			mysqli_close($con); 
		}
		?>
				
					<form method="POST" action="" onsubmit="return loginValidate()">
						<img class="img-responsive" alt="logo" src="img/logo.png">
						<table class='table'>
							<tr>
								<td>Email:</td>
								<td><input type="text" name="email" id="email" class="form-control"></td>
							</tr>
							<tr>
								<td>Password:</td>
								<td><input type="password" name="pwd" id="pwd" class="form-control"></td>
							</tr>
				
						</table>
						<label><a href="forgot.php">Forget Password?</a></label>
						<input type="submit" class="btn btn-primary" value="Login" name="login">
						<p>Have't Any Account <a href="register.php">Create An Account</a></p>
					</form>
				</div>
			</div>
		</section>
		<script>
			function loginValidate()
			{
				//email validation
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					document.getElementById("email").focus();
					return false;
				}else
				{
					var e=document.getElementById("email").value;
					var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
					
					if(!regexEmail.test(e))
					{
						alert("Enter a Valid Email");
						return false;
					}
				}
				if(document.getElementById("pwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
				
			}
		</script>
		<!-- login section End -->	
		
		<?php include("footer.php");?>