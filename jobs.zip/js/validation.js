function empValidation()
{
	if(document.getElementById("ename").value=="")
	{
		alert("Enter Employee Name");
		document.getElementById("ename").focus();
		return false;
	}
	//email validation
	if(document.getElementById("email").value=="")
	{
		alert("Enter Email");
		document.getElementById("email").focus();
		return false;
	}else
	{
		var e=document.getElementById("email").value;
		var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
		
		if(!regexEmail.test(e))
		{
			alert("Enter a Valid Email");
			return false;
		}
	}
	//mobile validation
	if(document.getElementById("mobile").value=="")
	{
		alert("Enter Mobile number");
		return false;
	}
	else
	{
		var mob=document.getElementById("mobile").value
		var IndNum = /^[0]?[6789]\d{9}$/;
		if(!IndNum.test(mob))
		{
			alert("Enter a 10 digit valid mobile number");
			return false;
		}
		
	}
}