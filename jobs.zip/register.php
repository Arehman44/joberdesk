<?php include("header.php"); ?>
		<section class="inner-banner" style="backend:#242c36 url(https://via.placeholder.com/1920x600)no-repeat;">
			<div class="container">
				<div class="caption">
					<h2>Create an Account</h2>
					
				</div>
			</div>
		</section>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<?php 
		if(isset($_POST['register']))
		{
			//collecting form data
			$name=$_POST['uname'];
			$email=$_POST['email'];
			$pwd=md5($_POST['pass']);
			$mobile=$_POST['mobile'];
			$gender=$_POST['gender'];
			$dob=$_POST['dob'];
			$city=$_POST['city'];
			$state=$_POST['state'];
			$address=$_POST['address'];
			$pincode=$_POST['pin'];
			$terms=$_POST['terms'];
			$ip=$_SERVER['REMOTE_ADDR'];
			//db connection
		//$con=mysqli_connect("localhost","root","","7am");
			//insert data into db table
			
			mysqli_query($con,"insert into register(username,email,password,mobile,gender,dob,address,city,state,pincode,terms,ip) values('$name','$email','$pwd','$mobile','$gender','$dob','$address','$city','$state','$pincode','$terms','$ip')");
			
			if(mysqli_affected_rows($con)==1)
			{
				$id=mysqli_insert_id($con);
				$to=$email;
				$subject="Account Activation link";
				$message="Hi ".$name.",<br><br>Thanks for creating an account with us. please click the below link to activate your account<br><br><a target='_blank' href='http://localhost:90/7am/activate.php?uid=$id'>Activate Now</a><br><br>Thanks<br>Team";
				$mheaders="Content-Type:text/html";
				//echo $message;
				if(mail($to,$subject,$message,$mheaders))
				{
					echo "<p class='alert alert-success'>Account Created Successfully. Please activate your account</p>";
				}
				else
				{
					echo "<P class='alert alert-danger'>Unbale to send an Email. please contact Admin</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger'>Sorry! Unable to process. Try Again</p>";
			}
			
		}
		
		?>
		<form method="POST" action="" onsubmit="return validate()">
			<table id="customers" class="table">
				<tr>
					<td>Username</td>
					<td><input type="text" name="uname" id="uname" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Password</td>
					<td><input type="password" name="pass" id="pass" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Confirm Password</td>
					<td><input type="password" name="cpass" id="cpass" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Gender</td>
					<td>
						<input type="radio" name="gender" value="Male">Male &nbsp;
						<input type="radio" name="gender" value="Female">Female &nbsp;
					</td>
				</tr>
				
				<tr>
					<td>Date of Birth</td>
					<td><input type="text" name="dob" id="dob" placeholder="YYYY-MM-DD" class="form-control"></td>
				</tr>
				
				<tr>
					<td>Address</td>
					<td><textarea class="form-control" id="address" name="address"></textarea></td>
				</tr>
				
				<tr>
					<td>City</td>
					<td><input class="form-control" type="text" name="city" id="city"></td>
				</tr>
				
				<tr>
					<td>State</td>
					<td>
		<select id="state" name="state" class="form-control">
			<option value="">--Select State--</option>
			<option value="Andhrapradesh">Andhrapradesh</option>
			<option value="Telangana">Telangana</option>
		</select>
					</td>
				</tr>
				
				<tr>
					<td>Pincode</td>
					<td><input class="form-control" type="text" name="pin" id="pin"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="checkbox" name="terms" id="terms" value="1">Please Accept terms&Conditions</td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" name="register" value="Register" class="btn btn-primary"></td>
				</tr>
				
			</table>
		</form>
					
					</div>
				</div>
			</div>
		</section>
		<script>
		function validate()
		{
			if(document.getElementById("uname").value=="")
			{
				alert("Enter Username");
				document.getElementById("uname").focus();
				return false;
			}
			//email validation
			if(document.getElementById("email").value=="")
			{
				alert("Enter Email");
				document.getElementById("email").focus();
				return false;
			}else
			{
				var e=document.getElementById("email").value;
				var regexEmail = /\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
				
				if(!regexEmail.test(e))
				{
					alert("Enter a Valid Email");
					return false;
				}
			}
			//mobile validation
			if(document.getElementById("mobile").value=="")
			{
				alert("Enter Mobile number");
				return false;
			}
			else
			{
				var mob=document.getElementById("mobile").value
				var IndNum = /^[0]?[6789]\d{9}$/;
				if(!IndNum.test(mob))
				{
					alert("Enter a 10 digit valid mobile number");
					return false;
				}
				
			}
		}
		</script>
	<?php include("footer.php"); ?>