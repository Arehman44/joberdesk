<?php 
include("header.php");
?>
		<section class="inner-banner" style="backend:#242c36 url(https://via.placeholder.com/1920x600)no-repeat;">
			<div class="container">
				<div class="caption">
					<h2>Forgot Password</h2>
					
				</div>
			</div>
		</section>
		<section class="jobs">
			<div class="container">
				<div class="row">
		<?php 
		if(isset($_POST['submit']))
		{
			$email=$_POST['email'];
			$res=mysqli_query($con,"select *from register where email='$email'");
			if(mysqli_num_rows($res)==1)
			{
				$row=mysqli_fetch_assoc($res);
				$uid=base64_encode($row['id']);
				$to=$email;
				$subject="Forgot Password-gophp";
				$message="Hi ".$row['username']."<br><br>Your forgot password request has been received. Please click the below link to reset your password.<br><br><a href='http://localhost:90/jobs/reset_pwd.php?uid=$uid'>Reset Password</a><br><br>Thanks<br>Team";
				$mheaders="Content-Type:text/html";
				if(mail($to,$subject,$message,$mheaders))
				{
					echo "<p class='alert alert-success'>Reset Password Link has sent to your email.please check</p>";
				}
				else
				{
					echo "<p class='alert alert-danger'>Sorry! Try Again</p>";
				}
			}
			else
			{
				echo "<p class='alert alert-danger'>Sorry! Email does not exists</p>";
			}
		}
		?>
		
		<form method="POST" action="" onsubmit="return validate()">
			Enter Email:<input class="form-control" type="text" name="email" id="email">
			<input type="submit" class="btn btn-primary" name="submit" value="Submit">
		</form>
	</div>
	</div>
	</section>
		<script>
			function validate()
			{
				if(document.getElementById("email").value=="")
				{
					alert("Enter Email");
					return false;
				}
			}
		</script>
	<?php 
include("footer.php");
?>