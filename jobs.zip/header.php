<?php session_start();
include("connect.php");
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Jober Desk | Responsive Job Portal Template</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
        <!-- All Plugin Css --> 
		<link rel="stylesheet" href="css/plugins.css">
		
		<!-- Style & Common Css --> 
		<link rel="stylesheet" href="css/common.css">
        <link rel="stylesheet" href="css/main.css">

    </head>
	
    <body>
	
		<!-- Navigation Start  -->
		<nav class="navbar navbar-default navbar-sticky bootsnav">

			<div class="container">      
				<!-- Start Header Navigation -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
						<i class="fa fa-bars"></i>
					</button>
					<a class="navbar-brand" href="index.php"><img src="img/logo.png" class="logo" alt=""></a>
				</div>
				<!-- End Header Navigation -->

				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="navbar-menu">
					<ul class="nav navbar-nav navbar-right" data-in="fadeInDown" data-out="fadeOutUp">
							<li><a href="index.php">Home</a></li> 
							
							<li><a href="companies.php">Companies</a></li> 
							
							<li><a href="contact.php">Contact us</a></li>
							<?php 
							if(isset($_SESSION['logintrue']))
							{
								$logid=$_SESSION['logintrue'];
								$query=mysqli_query($con,"select username,profile_pic from register where id=$logid");
								$qrow=mysqli_fetch_assoc($query);
								
								?>
									<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php 
							if($qrow['profile_pic']!="")
							{
								?>
									<img src="profiles/<?php echo $qrow['profile_pic']?>" class="header-circle" height="25" width="25">
								<?php
							}
							else
							{
								?>
									<img src="img/avatar.png" class="header-circle" height="25" width="25">
								<?php
							}
							?><?php echo ucfirst($qrow['username']);?></a>
								<ul class="dropdown-menu animated fadeOutUp" style="display: none; opacity: 1;">
									<li class=""><a href="home.php">My Profile</a></li>
									<li><a href="#">Edit Profile</a></li>
									<li><a href="logout.php">Logout</a></li>
								</ul>
							</li>
								<?php
							}else
							{
								?>
									<li><a href="login.php">Login</a></li>
								<?php
							}
							
							?>
							
							
						</ul>
				</div><!-- /.navbar-collapse -->
			</div>   
		</nav>
		<!-- Navigation End  -->