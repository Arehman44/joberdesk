<?php 
session_start();
if(isset($_SESSION['logintrue']))
{
	include("connect.php");
	if(isset($_REQUEST['jid']))
	{
		$id=$_REQUEST['jid'];
		$jinfo=mysqli_query($con,"select title,company from jobs where jid=$id");
		$jrow=mysqli_fetch_assoc($jinfo);
		
		$userid=$_SESSION['logintrue'];
		$uinfo=mysqli_query($con,"select email,username,mobile from register where id=$userid");
		$urow=mysqli_fetch_assoc($uinfo);
		
		$to="rambabburi@gmail.com";
		$subject="Job Apply Notification From ".$urow['username'];
		$message="Hi Admin,<br><br>Mr/Mrs. ".$urow['username']." applied for the position of ".$jrow['title']." find the user details below<br><br>
		Name: ".$urow['username']."<br>
		Mobile: ".$urow['mobile']."<br>
		Email: ".$urow['email']."<br><br>
		Thanks<br>Team<br>";
		$mheaders="Content-Type:text/html";
		
		if(mail($to,$subject,$message,$mheaders))
		{
			setcookie("success","Applied Successfully. Get back you soon",time()+2);
			header("Location:view_job.php?jid=$id");
		}
		else
		{
			setcookie("success","Applied Successfully. Get back you soon",time()+2);
			header("Location:view_job.php?jid=$id");
		}
	}
	else
	{
		exit();
	}
}
else
{
	header("location:login.php");
}
?>