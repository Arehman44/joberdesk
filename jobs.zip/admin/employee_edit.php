<?php ob_start(); 
include("header.php");

if(isset($_REQUEST['empid']))
{
	$eid=$_REQUEST['empid'];
	$edata=mysqli_query($con,"select *from employee where eid=$eid");
	
	if(mysqli_num_rows($edata))
	{
		$erow=mysqli_fetch_assoc($edata);
	}
	else{
		exit("Sorry!");
	}
}

?>
<div class="container-fluid">

          <!-- Page Heading -->
	 
		<h1 class="h3 mb-0 text-gray-800">Edit Employee</h1>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo $_COOKIE['success'];
		}
		
		
		if(isset($_POST['submit']))
		{
			$name=$_POST['ename'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			$desg=$_POST['desg'];
			$salary=$_POST['salary'];
			$city=$_POST['city'];
			
			mysqli_query($con,"update employee set name='$name',email='$email',mobile='$mobile',city='$city',designation='$desg',salary='$salary' where eid=$eid");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","<p class='alert alert-success'>Employee Updated successfully</p>",time()+2);
				header("Location:employee_edit.php?empid=$eid");
			}
			else
			{
				echo "<p class='alert alert-danger'>Unable to add. Try Again</p>";
			}
			
		}
		?>
		
		<form method="post" action="" onsubmit="return empValidation()">
			<table class="table">
				<tr>
					<td>Employee Name</td>
					<td><input type="text" name="ename" id="ename" class="form-control" value="<?php echo $erow['name']; ?>"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" class="form-control" value="<?php echo $erow['email']; ?>"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" class="form-control" value="<?php echo $erow['mobile']; ?>"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary" class="form-control" value="<?php echo $erow['salary']; ?>"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><input type="text" name="desg" id="desg" class="form-control" value="<?php echo $erow['designation']; ?>"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city" class="form-control" value="<?php echo $erow['city']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Update Employee" class="btn btn-success"></td>
				</tr>
			</table>
		</form>
		</div>
		<script src="js/validation.js"></script>
	<?php include("footer.php");
	ob_end_flush();
	?>