<?php include("header.php");?>
<link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<div class="container-fluid">

          <!-- Page Heading -->
	 
		<h1 class="h3 mb-0 text-gray-800">View Jobs</h1>

		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<P class='alert alert-success'>".$_COOKIE['success']."</p>";
		}
		?>
		
		<?php 
		$result=mysqli_query($con,"select *from jobs order by jid DESC");
		if(mysqli_num_rows($result)>0)
		{
			?>
				<div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
				<thead>
			<tr>
				<th>Jid</th>
				<th>Title</th>
				<th>Exp</th>
				<th>Salary</th>
				<th>Company</th>
				<th>Address</th>
				<th>DOI</th>
				<th>Mobile</th>
				<th>Action</th>
			</tr>
			</thead>
			<tfoot>
			<tr>
				<th>Jid</th>
				<th>Title</th>
				<th>Exp</th>
				<th>Salary</th>
				<th>Company</th>
				<th>Address</th>
				<th>DOI</th>
				<th>Mobile</th>
				<th>Action</th>
			</tr>
			</tfoot>
			<tbody>
			<?php 
			while($row=mysqli_fetch_assoc($result))
			{
				?>
					<tr>
				<td><?php echo $row['jid'];?></td>
				<td><?php echo $row['title'];?></td>
				<td><?php echo $row['experience'];?></td>
				<td><?php echo $row['salary'];?></td>
				<td><?php echo $row['cname'];?></td>
				<td><?php echo $row['address'];?></td>
				<td><?php echo $row['doi'];?></td>
				<td><?php echo $row['mobile'];?></td>
				<td><a href="job_edit.php?jid=<?php echo $row['jid'];?>">Edit</a> | <a href="javascript:void(0)" onclick="deleteRecord(<?php echo $row['jid'];?>)">Delete</a></td>
				
			</tr>
				<?php
			}
			?>
			</tbody>
		</table>
			<?php
		}
		else
		{
			echo "<p>No Records Found</p>";
		}
		?>
		<script>
			function deleteRecord(id)
			{
				var c=confirm("Do you want to Delete?");
				if(c==true)
				{
					window.location="job_delete.php?did="+id;
				}
			}
		</script>
		</div>
	<?php include("footer.php");?>

 <!-- Page level plugins -->
  <script src="vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/datatables-demo.js"></script>

