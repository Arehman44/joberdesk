<?php 
session_start();
if(isset($_SESSION['adminlogintrue']))
{
	if(isset($_REQUEST['did']))
	{
		$id=$_REQUEST['did'];
		include("../connect.php");
		mysqli_query($con,"delete from jobs where jid=$id");
		if(mysqli_affected_rows($con)==1)
		{
			setcookie("success","Record Deleted Successfully",time()+2);
			header("Location:jobs_view.php");
		}
	}
}
?>