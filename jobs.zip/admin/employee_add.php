<?php 
ob_start();
include("header.php");
?>
<div class="container-fluid">

          <!-- Page Heading -->
	 
		<h1 class="h3 mb-0 text-gray-800">Add Employee</h1>

		<?php 
		if(isset($_COOKIE['success']))
		{
			echo $_COOKIE['success'];
		}
		
		
		if(isset($_POST['submit']))
		{
			$name=$_POST['ename'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			$desg=$_POST['desg'];
			$salary=$_POST['salary'];
			$city=$_POST['city'];
			
			mysqli_query($con,"insert into employee(name,email,mobile,salary,city,designation) values('$name','$email','$mobile','$salary','$city','$desg')");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","<p class='alert alert-success'>Employee Added successfully</p>",time()+2);
				header("Location:employee_add.php");
				
			}
			else
			{
				echo "<p class='alert alert-danger'>Unable to add. Try Again</p>";
			}
			
		}
		?>
		
		<form method="post" action="" onsubmit="return empValidation()">
			<table class="table">
				<tr>
					<td>Employee Name</td>
					<td><input type="text" name="ename" id="ename" class="form-control"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" class="form-control"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" class="form-control"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary" class="form-control"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><input type="text" name="desg" id="desg" class="form-control"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city" class="form-control"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Add Employee" class="btn btn-primary"></td>
				</tr>
			</table>
		</form>
		</div>
		
		<script src="js/validation.js"></script>
	<?php 
include("footer.php");
ob_end_flush();
?>