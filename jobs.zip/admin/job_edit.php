<?php ob_start(); include("header.php"); 
if(isset($_REQUEST['jid']))
{
	$jid=$_REQUEST['jid'];
	$res=mysqli_query($con,"select *from jobs where jid=$jid");
	if(mysqli_num_rows($res)==1)
	{
		$row=mysqli_fetch_assoc($res);
	}
	else
	{
		?>
		<script>alert("Sorry, No Records Found");</script>
	<?php
	exit("<p class='alert alert-danger'>Error, No Records Found</p>");
	}
}
else
{
	?>
		<script>alert("Sorry");</script>
	<?php
	exit("Error");
}

?>
<link href="css/bootstrap-datepicker.css" rel="stylesheet">
<div class="container-fluid">
	<h1 class="h3 mb-0 text-gray-800">Edit Job</h1><br>
	<div class="row">
		<div class="col-lg-12">
		
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
		}
		
		if(isset($_POST['submit']))
		{
			$title=$_POST['title'];
			$jd=$_POST['jd'];
			$salary=$_POST['salary'];
			$skills=$_POST['skills'];
			$doi=$_POST['doi'];
			$exp=$_POST['exp'];
			$cname=$_POST['cname'];
			$address=$_POST['address'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			
			if(is_uploaded_file($_FILES['logo']['tmp_name']))
			{
				$filename=$_FILES['logo']['name'];
				$tpath=$_FILES['logo']['tmp_name'];
				move_uploaded_file($tpath,"logos/$filename");
			}
			else
			{
				$filename=$row['logo'];
			}
			
			mysqli_query($con,"update jobs set 
			title='$title',
			description='$jd',
			experience='$exp',
			salary='$salary',
			skills='$skills',
			doi='$doi',
			address='$address',
			cname='$cname',
			email='$email',
			mobile='$mobile',
			logo='$filename' where jid=$jid");
			
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","Job Updated Successfully",time()+2);
				header("location:job_edit.php?jid=$jid");
			}
			else
			{
				echo "<p class='alert alert-danger'>Unable to Update. Try Again</p>";
			}
			
			
		}
		?>
		
			<form method="POST" action="" enctype="multipart/form-data" onsubmit="return jobValidate()">
			
				<div class="form-group">
					<label>Job Title</label>
					<span id="title-error" class='float-right text-danger'></span>
					<input type="text" name="title" class="form-control" id="title" onblur="checkValue(this)" value="<?php echo $row['title'] ?>">
				</div>
				
				<div class="form-group">
					<label>Job Description</label>
					<span id="jd-error" class='float-right text-danger'></span>
					<textarea name="jd" class="form-control" id="jd" onblur="checkValue(this)"><?php echo $row['description'] ?></textarea>
				</div>
				
				<div class="form-group">
					<label>Salary</label>
					<input type="text" name="salary" class="form-control" id="salary" value="<?php echo $row['salary']; ?>">
				</div>
				
				<div class="form-group">
					<label>Skills or Technology Required</label>
					<input type="text" name="skills" class="form-control" id="skills" value="<?php echo $row['skills'] ?>">
				</div>
				
				<div class="form-group">
					<label>Experience</label>
					<input type="text" name="exp" class="form-control" id="exp" placeholder="Fresher, 0-4 Years exp, 5-10 Years exp" value="<?php echo $row['experience'] ?>">
				</div>
				
				<div class="form-group">
				<label>Date of Interview</label>
					<input type="text" id="dp" name="doi" class="form-control" value="<?php echo $row['doi'] ?>">
				</div>
				
				<div class="form-group">
					<label>Company Name</label>
					<input type="text" name="cname" class="form-control" id="cname" value="<?php echo $row['cname'] ?>">
				</div>
				
				<div class="form-group">
					<label>Address</label>
					<textarea name="address" class="form-control" id="address"><?php echo $row['address'] ?></textarea>
				</div>
				
				<div class="form-group">
					<label>Email</label>
					<input type="text" name="email" class="form-control" id="email" value="<?php echo $row['email'] ?>">
				</div>
				
				<div class="form-group">
					<label>Contact Numbers</label>
					<input type="text" name="mobile" class="form-control" id="mobile" value="<?php echo $row['mobile'] ?>">
				</div>
				
				<div class="form-group">
					<label>Upload Logo</label>
					<input type="file" name="logo" class="form-control" id="logo">
					<?php 
					if($row['logo']!="")
					{
						?>
							<img src="logos/<?php echo $row['logo'];?>" height="50" width="50">
						<?php
					}
					
					?>
				</div>
				
				<div class="form-group">
					
					<input type="submit" name="submit" class="btn btn-primary" Value="Update Job">
				</div>
			</form>
		</div>
	</div>
</div>
<script>
function jobValidate()
{
	if($("#title").val()=="")
	{
		$("#title-error").html("This field is required");
		$("#title").focus();
		return false;
	}
	//document.getElementById("jd").value;
	if($("#jd").val()=="")
	{
		$("#jd-error").html("This filed is required");
		$("#jd").focus();
		return false;
	}
}

//blur

function checkValue(ele)
{
	if(ele.value!="")
	{
		$("#"+ele.id+"-error").html("");
	}
	
}



</script>

<?php include("footer.php"); ?>

<script src="js/bootstrap-datepicker.js"></script>
<script>
	$('#dp').datepicker({
		format: 'yyyy-mm-dd',
	});
</script>
<?php ob_end_flush();?>