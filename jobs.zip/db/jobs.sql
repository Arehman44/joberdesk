-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 10, 2019 at 12:21 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'Admin', 'admin@mail.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(20) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `message`) VALUES
(1, 'Ram', 'ram@mail.com', 345345345, 'hello'),
(2, 'siva', 'siva@mail.com', 2423423423, 'Hi how are you'),
(3, 'Naresh', 'naresh@mail.com', 2423423423, 'hello how are you'),
(4, 'koti', 'koti@mail.com', 23423423, 'hello'),
(5, 'Lakshmi', 'lakshmi@mail.com', 43534534, 'hello'),
(6, 'test', 'yest@mail.com', 434534345634, 'dfgdfgdfgdfgdf'),
(7, 'Ram', 'rambabburi@gmail.com', 9885774764, 'test'),
(8, 'hello', 'admin@mail.com', 98857747640, 'asdsdas'),
(9, 'naresh', 'naresh@mail.com', 23423423423, 'sdfsdfsd'),
(10, 'Ram', 'rambabburi@gmail.com', 9885774764, 'sdfsdf'),
(11, 'Ram', 'rambabburi@gmail.com', 9885774764, 'sdfsdf'),
(12, 'Ram', 'rambabburi@gmail.com', 9885774764, 'dasd'),
(13, 'Ram', 'rambabburi@gmail.com', 9885774764, 'sdf'),
(14, 'Ram', 'naresh@mail.com', 9885774764, 'sfdsdf'),
(15, 'Ram', 'naresh@mail.com', 9885774764, 'sfdsdf');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `eid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `salary` int(11) NOT NULL,
  `city` varchar(105) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`eid`, `name`, `email`, `mobile`, `salary`, `city`, `designation`, `date`) VALUES
(1, 'Ram Kumar', 'ram@mail.com', '9885774764', 12000, 'Hyderabad', 'Developer', '2019-02-05 08:03:58'),
(2, 'Ram Kumar', 'ramkumar@mail.com', '9885774764', 15000, 'Delhi', 'Developer', '2019-02-05 08:04:31'),
(3, 'Siva', 'siva@mail.com', '9212121212', 12000, 'Hyderabad', 'Developer', '2019-02-05 08:05:59'),
(4, 'Ram', 'rambabburi@gmail.com', '9885774764', 12000, 'Hyderabad', 'Developer', '2019-02-08 08:08:49');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `jid` int(11) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `salary` varchar(100) NOT NULL,
  `skills` text NOT NULL,
  `experience` varchar(150) NOT NULL,
  `doi` date NOT NULL,
  `cname` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `email` varchar(150) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `logo` text NOT NULL,
  `posted_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`jid`, `title`, `description`, `salary`, `skills`, `experience`, `doi`, `cname`, `address`, `email`, `mobile`, `logo`, `posted_date`) VALUES
(1, 'PHP Job Openings in Swayam Group ', '<ul>\r\n<li>Good in Object orented concepts</li>\r\n<li>Sound knowledge in Javascript</li>\r\n</ul>', '50000-60000', 'HTML, CSS, Bootsrap, JavaScript, jQuery, Ajax, PHP&mySQL, Codeigniter, Wordpress', '0-2 years', '2019-02-13', 'Swayam Group', 'The Platina, Gachibowli,\r\nLandmak: Near Radisson Hotel', 'rambabburi@gmail.com', '9885774764', 'logo.png', '2019-02-10 10:06:17'),
(2, 'Java Freshers pleacement Drive', '<ul>\r\n<li>Good in Object orented concepts</li>\r\n<li>Sound knowledge in Javascript</li>\r\n</ul>', '50000-60000', 'HTML, CSS, Bootsrap, JavaScript, jQuery, Ajax, JAVA, Struts, Hibernet', '0-2 years', '2019-02-19', 'Naresh IT', 'SR Nagar', 'ram@mail.com', '9885774764', 'nareshit.png', '2019-02-10 11:10:08'),
(3, 'Job openings for .Net Developers in click and pledge', '<ul>\r\n<li>Good in Object orented concepts</li>\r\n<li>Sound knowledge in Javascript</li>\r\n</ul>', '70000-100000', 'HTML, CSS, Bootsrap, JavaScript, jQuery, Ajax,.Net, ASP.NET, C#', '6-8 Years', '2019-02-27', 'Click and Pledge', 'Gachbowli', 'rambabburi@gmail.com', '9885774764', 'cp-logo-main-website-sticky-e1508425773314.png', '2019-02-10 11:14:25');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `password` varchar(100) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `mobile`, `password`, `time_stamp`) VALUES
(1, 'shambu', 'sam@gmail.com', '2147483647', '123', '2019-02-06 07:25:53'),
(4, 'naveen123', 'naveen@gmail.com', '9652144712', '123', '2019-02-06 09:48:03'),
(7, 'hello', 'hello@gmail.com', '9652144712', '123', '2019-02-06 10:37:03'),
(8, 'shiva', 'shiva@gmail.com', '9494912536', '123', '2019-02-06 10:42:34');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `username` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(32) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `city` varchar(150) NOT NULL,
  `state` varchar(150) NOT NULL,
  `pincode` int(11) NOT NULL,
  `terms` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL DEFAULT 'Inactive',
  `ip` varchar(30) NOT NULL,
  `profile_pic` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `mobile`, `gender`, `dob`, `address`, `city`, `state`, `pincode`, `terms`, `created_date`, `status`, `ip`, `profile_pic`) VALUES
(1, 'Ram', 'rambabburi@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '9885774740', 'Male', '1987-07-25', 'Vengal Rao Nagar,SR Nagar', 'Hyderabad', 'Telangana', 500038, 1, '2019-01-27 08:29:13', 'Active', '::1', '3.jpg.jpg'),
(2, 'ram', 'ram@mail.com', '202cb962ac59075b964b07152d234b70', '9885774764', 'Male', '1987-07-25', 'SR Nagar', 'Hyderabad', 'Telangana', 500038, 1, '2019-01-27 08:40:25', 'Inactive', '::1', ''),
(3, 'naresh', 'naresh@mail.com', '202cb962ac59075b964b07152d234b70', '9885774764', 'Male', '1987-07-25', 'SR Nagar', 'Hyderabad', 'Telangana', 500038, 1, '2019-01-31 07:49:44', 'Active', '::1', '07e89096.jpg'),
(4, 'test', 'test@mail.com', '81dc9bdb52d04dc20036dbd8313ed055', '9885774764', 'Male', '1987-07-25', 'SR Nagar', 'Hyderabad', 'Telangana', 500038, 1, '2019-02-01 08:31:03', 'Inactive', '::1', '');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `name`) VALUES
(1, 'Ram'),
(2, 'Siva');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`eid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`jid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `jid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
