<?php 
include("header.php");
if(isset($_SESSION['logintrue']))
{
	$userid=$_SESSION['logintrue'];
		include("connect.php");
		$result=mysqli_query($con,"select *from register where id=$userid");
		$row=mysqli_fetch_assoc($result);
		
		?>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<h4>Welcome to <?php echo ucwords($row['username']);?></h4>
					<div class="col-md-3">
						<div class="vertical-menu">
							<?php 
							if($row['profile_pic']!="")
							{
								?>
									<img src="profiles/<?php echo $row['profile_pic']?>" class="my-circle" height="60" width="60">
								<?php
							}
							else
							{
								?>
									<img src="img/avatar.png" class="my-circle" height="60" width="60">
								<?php
							}
							?>
						  <a href="home.php">My Profile</a>
						  <a href="edit.php">Edit My Profile</a>
						  <a href="upload_avatar.php"  class='active'>Upload Avatar</a>
						  <a href="change_pwd.php">Change Password</a>
						  <a href="logout.php">Logout</a>
						</div>
					</div>
					<div class="col-md-9">
						<h6>Upload Avatar</h6>
						<?php 
						
						if(isset($_COOKIE['success']))
						{
							echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
						}
						
						if(isset($_POST['upload']))
						{
							
							if(is_uploaded_file($_FILES['image']['tmp_name']))
							{
								
								$filename=$_FILES['image']['name'];
								$size=$_FILES['image']['size'];
								$type=$_FILES['image']['type'];
								$path=$_FILES['image']['tmp_name'];
								
								$types=array(
									"image/jpg",
									"image/jpeg",
									"image/png",
									"image/gif",
								);
								
								if(in_array($type,$types))
								{
									
									if($size<=200000)
									{
										
										$status=move_uploaded_file($path,"profiles/$filename");
										if($status==1)
										{
								mysqli_query($con,"update register set profile_pic='$filename' where id=$userid");
								if(mysqli_affected_rows($con)==1)
								{
									setcookie("success","Avatar uploaded successfully",time()+2);
									header("Location:upload_avatar.php");
								}
										}
										else
										{
											echo "<p>Sorry! UNbale to Move. Try Again</p>";
										}
									}
									else
									{
										echo "<p class='alert alert-warning'>Uploaded filesize should below 2MB</p>";
									}
								}
								else
								{
									echo "<P>Please select a valid IMage</p>";
								}
								
							}
							else
							{
								echo "<p>Please select a file to upload</p>";
							}
						}
						?>
						
						
						<form method="POST" action="" enctype='multipart/form-data'>
							<div class='form-group'>
								<label>Please select a file to upload</label>
								<input type="file" name='image' class='form-control'>
							</div>
							<div class='form-group'>
								<input type="submit" name='upload' class='btn btn-primary'  value="Upload">
							</div>
						</form>
						
					</div>
				</div>
			</div>
		</section>
		<?php
}
else
{
	header("Location:login.php");
}
include("footer.php");
?>