<?php 
include("header.php");

if(isset($_SESSION['logintrue']))
{
		$userid=$_SESSION['logintrue'];
		include("connect.php");
		$result=mysqli_query($con,"select *from register where id=$userid");
		$row=mysqli_fetch_assoc($result);
		
		?>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<h4>Welcome to <?php echo ucwords($row['username']);?></h4>
					<div class="col-md-3">
						<div class="vertical-menu">
							<?php 
							if($row['profile_pic']!="")
							{
								?>
									<img src="profiles/<?php echo $row['profile_pic']?>" class="my-circle" height="60" width="60">
								<?php
							}
							else
							{
								?>
									<img src="img/avatar.png" class="my-circle" height="60" width="60">
								<?php
							}
							?>
						  <a href="home.php">My Profile</a>
						  <a href="edit.php">Edit My Profile</a>
						  <a href="upload_avatar.php">Upload Avatar</a>
						  <a href="change_pwd.php" class="active">Change Password</a>
						  <a href="logout.php">Logout</a>
						</div>
					</div>
					<div class="col-md-9">
						<h6>Change Password</h6>
						<?php 
						if(isset($_POST['update']))
						{
							$opwd=md5($_POST['opwd']);
							$npwd=md5($_POST['npwd']);
							$cnpwd=md5($_POST['cnpwd']);
							
							if($row['password']==$opwd)
							{
								if($npwd==$cnpwd)
								{
									mysqli_query($con,"update register set password='$npwd' where id=$userid");
									
									if(mysqli_affected_rows($con)==1)
									{
										echo "<p class='alert alert-success'>Password changed successfully</p>";
									}
								}
								else
								{
									echo "<p class='alert alert-danger'>New Password and COnfirm Password Does not matched</p>";
								}
							}
							else
							{
								echo "<p class='alert alert-danger'>Old Password Does not matched</p>";
							}
						}
						?>
						
						<form method="POST" action="">
							<div class="form-group">
								<label>Enter Old Password</label>
								<input type="password" name="opwd" id="opwd" class="form-control">
							</div>
							
							<div class="form-group">
								<label>Enter New Password</label>
								<input type="password" name="npwd" id="npwd" class="form-control">
							</div>
							
							<div class="form-group">
								<label>Confirm New Password</label>
								<input type="password" name="cnpwd" id="cnpwd" class="form-control">
							</div>
							
							<div class="form-group">
								<input type="submit" name="update" value="Update" class="btn btn-primary">
							</div>
							
						</form>
					</div>
				</div>
			</div>
		</section>
		<?php
}
else
{
	header("Location:login.php");
}
include("footer.php");
?>