<?php 
if(isset($_REQUEST['did']))
{
	$id=$_REQUEST['did'];
	include("connect.php");
	mysqli_query($con,"delete from employee where eid=$id");
	if(mysqli_affected_rows($con)==1)
	{
		setcookie("success","Record Deleted Successfully",time()+2);
		header("Location:employee_view.php");
	}
}
?>