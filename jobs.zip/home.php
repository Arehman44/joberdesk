<?php include("header.php"); ?>
		
	<?php 
	if(isset($_SESSION['logintrue']))
	{
		$userid=$_SESSION['logintrue'];
		include("connect.php");
		$result=mysqli_query($con,"select *from register where id=$userid");
		$row=mysqli_fetch_assoc($result);
		
		?>
		<section class="jobs">
			<div class="container">
				<div class="row">
					<h4>Welcome to <?php echo ucwords($row['username']);?></h4>
					<div class="col-md-3">
						<div class="vertical-menu">
							<?php 
							if($row['profile_pic']!="")
							{
								?>
									<img src="profiles/<?php echo $row['profile_pic']?>" class="my-circle" height="60" width="60">
								<?php
							}
							else
							{
								?>
									<img src="img/avatar.png" class="my-circle" height="60" width="60">
								<?php
							}
							?>
						  <a href="home.php" class='active'>My Profile</a>
						  <a href="edit.php">Edit My Profile</a>
						  <a href="upload_avatar.php">Upload Avatar</a>
						  <a href="change_pwd.php">Change Password</a>
						  <a href="logout.php">Logout</a>
						</div>
					</div>
					<div class="col-md-9">
						<table class="table">
					<tr>
						<td>Name</td>
						<td><?php echo ucwords($row['username']);?></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><?php echo $row['email']?></td>
					</tr>
					<tr>
						<td>Gender</td>
						<td><?php echo $row['gender']?></td>
					</tr>
					<tr>
						<td>DOB</td>
						<td><?php echo $row['dob']?></td>
					</tr>
					<tr>
						<td>Mobile</td>
						<td><?php echo $row['mobile']?></td>
					</tr>
					<tr>
						<td>City</td>
						<td><?php echo $row['city']?></td>
					</tr>
					<tr>
						<td>State</td>
						<td><?php echo $row['state']?></td>
					</tr>
					<tr>
						<td>Address</td>
						<td><?php echo $row['address']?></td>
					</tr>
					<tr>
						<td>Registered Date</td>
						<td><?php echo $row['created_date']?></td>
					</tr>
				</table>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
	else
	{
		header("Location:login.php");
	}
	?>
		
<?php include("footer.php"); ?>