<?php 

include("header.php"); 
if(isset($_REQUEST['jid']))
{
	$jid=$_REQUEST['jid'];
	$query=mysqli_query($con,"select *from jobs where jid=$jid");
	if(mysqli_num_rows($query)==1)
	{
		$row=mysqli_fetch_array($query);
	}
	else
	{
		exit();
	}
}
else
{
	exit();
}
?>
		
		<section class="jobs">
			<div class="container">
				<div class="row">
					<div class='col-md-3'>
						<h4>Related Jobs</h4>
						<?php 
						$jobs=mysqli_query($con,"select title,jid from jobs where jid != $jid order by jid desc limit 20");
						if(mysqli_num_rows($jobs)>0)
						{
							echo "<ul>";
							while($jrow=mysqli_fetch_assoc($jobs))
							{
								?>
									<li><a href='view_job.php?jid=<?php echo $jrow['jid']?>'><?php echo $jrow['title']?></a></li>
								<?php
							}
							echo "</ul>";
						}
						else
						{
							echo "<p>No Related Jobs founs</p>";
						}
						?>
						
					</div>
					<div class='col-md-9'>
					<?php 
					if(isset($_COOKIE['success']))
					{
						echo "<p class='alert alert-success'>".$_COOKIE['success']."</p>";
					}
					?>
						<h4><?php echo $row['title'];?></h4>
					<p><b>Company: </b> <?php echo $row['cname'];?></p>
					<p><b>Date of Interview: </b> <?php echo date("l, dS F Y",strtotime($row['doi']));?></p>
					
					<p><b>Salary: </b> <?php echo $row['salary'];?></p>
					
					<p><b>Required Skills: </b> <?php echo $row['skills'];?></p>
					
					<p><b>Experience: </b> <?php echo $row['experience'];?></p>
					<p><b><u>Job Description</u></b></p>
					<p><?php echo $row['description'];?></p>
					<hr/>
					<p><b>Address:</b></p>
					<?php echo $row['address'];?><br>
					Email: <?php echo $row['email'];?><br>
					Mobile: <?php echo $row['mobile'];?><br>
					
					<hr/>
					<?php 
					if(isset($_SESSION['logintrue']))
					{
						?>
						<a class='btn btn-success' href="apply.php?jid=<?php echo $row['jid']?>">Apply Now</a>
						<?php
					}
					else
					{
						?>
						<a class="btn btn-primary" href="login.php">Login to apply</a>
						<?php
					}
					?>
						
						
					<hr/>
					</div>
				</div>
			</div>
		</section>
		
	<?php include("footer.php"); ?>