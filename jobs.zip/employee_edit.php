<?php 
include("connect.php");

if(isset($_REQUEST['empid']))
{
	$eid=$_REQUEST['empid'];
	$edata=mysqli_query($con,"select *from employee where eid=$eid");
	
	if(mysqli_num_rows($edata))
	{
		$erow=mysqli_fetch_assoc($edata);
	}
	else{
		exit("Sorry!");
	}
}

?>
<html>
	<head>
		<title>CRUD Operation | Add Employee</title>
	</head>
	<body>
		<h1>Edit Employee</h1>
		<p><a href="employee_view.php">View Employees</a></p>
		<?php 
		if(isset($_COOKIE['success']))
		{
			echo $_COOKIE['success'];
		}
		
		
		if(isset($_POST['submit']))
		{
			$name=$_POST['ename'];
			$email=$_POST['email'];
			$mobile=$_POST['mobile'];
			$desg=$_POST['desg'];
			$salary=$_POST['salary'];
			$city=$_POST['city'];
			
			mysqli_query($con,"update employee set name='$name',email='$email',mobile='$mobile',city='$city',designation='$desg',salary='$salary' where eid=$eid");
			if(mysqli_affected_rows($con)==1)
			{
				setcookie("success","<p>Employee Updated successfully</p>",time()+2);
				header("Location:employee_edit.php?empid=$eid");
			}
			else
			{
				echo "<p>Unable to add. Try Again</p>";
			}
			
		}
		?>
		
		<form method="post" action="" onsubmit="return empValidation()">
			<table>
				<tr>
					<td>Employee Name</td>
					<td><input type="text" name="ename" id="ename" value="<?php echo $erow['name']; ?>"></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="text" name="email" id="email" value="<?php echo $erow['email']; ?>"></td>
				</tr>
				<tr>
					<td>Mobile</td>
					<td><input type="text" name="mobile" id="mobile" value="<?php echo $erow['mobile']; ?>"></td>
				</tr>
				<tr>
					<td>Salary</td>
					<td><input type="text" name="salary" id="salary" value="<?php echo $erow['salary']; ?>"></td>
				</tr>
				<tr>
					<td>Designation</td>
					<td><input type="text" name="desg" id="desg" value="<?php echo $erow['designation']; ?>"></td>
				</tr>
				<tr>
					<td>City</td>
					<td><input type="text" name="city" id="city" value="<?php echo $erow['city']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="Update Employee"></td>
				</tr>
			</table>
		</form>
		<script src="js/validation.js"></script>
	</body>
</html>