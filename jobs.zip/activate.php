<?php
if(isset($_REQUEST['uid']))
{
	$id=$_REQUEST['uid'];
	//$con=mysqli_connect("localhost","root","","7am");
	include("connect.php");
	mysqli_query($con,"update register set status='Active' where id=$id");
	if(mysqli_affected_rows($con)==1)
	{
		echo "Account Activated Successfully";
	}
	else
	{
		echo "Please check your account may already activated";
	}
}

?>