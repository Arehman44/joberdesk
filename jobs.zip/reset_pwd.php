<?php 
include("header.php");

if(isset($_REQUEST['uid']))
{
	$id=base64_decode($_REQUEST['uid']);
	?>
		<section class="inner-banner" style="backend:#242c36 url(https://via.placeholder.com/1920x600)no-repeat;">
			<div class="container">
				<div class="caption">
					<h2>Reset Password</h2>
					
				</div>
			</div>
		</section>
		<section class="jobs">
			<div class="container">
				<div class="row">
				
				<?php 
				if(isset($_POST['update']))
				{
					
					$npwd=md5($_POST['npwd']);
					$cnpwd=md5($_POST['cnpwd']);
					if($npwd==$cnpwd)
					{
						mysqli_query($con,"update register set password='$npwd' where id=$id");
						if(mysqli_affected_rows($con)>0)
						{
							echo "<p>Password changed successfully.Please <a href='login.php'>login</a> Now</p>";
						}
						else
						{
							echo "<p>Sorry! Unable to update.try again</p>";
						}
					}
					else
					{
						echo "<p>Passwords Does not Matched</p>";
					}
				}
				?>
				
				<form method="POST" action="" onsubmit="return validate()">
					<table class="table">
						<tr>
							<td>Enter New Password</td>
							<td><input class="form-control" type="password" name="npwd" id="npwd"></td>
						</tr>
						
						<tr>
							<td>Confirm New Password</td>
							<td><input type="password" class="form-control" name="cnpwd" id="cnpwd"></td>
						</tr>
						<tr>
							<td></td>
							<td><input class="btn btn-primary" type="submit" name="update" value="Update"></td>
						</tr>
					</table>
				
				</form>
				
				
			</div>
		</div>
	</section>
	<script>
			function validate()
			{
				if(document.getElementById("npwd").value=="")
				{
					alert("Enter Password");
					return false;
				}
				if(document.getElementById("cnpwd").value=="")
				{
					alert("Enter Confirm Password");
					return false;
				}
				if(document.getElementById("cnpwd").value != document.getElementById("npwd").value)
				{
					alert("Passwords Does not matched");
					return false;
				}
				
				
			}
				</script>
			
	<?php
}
else
{
	exit("Wrong Window");
}
include("footer.php");
?>